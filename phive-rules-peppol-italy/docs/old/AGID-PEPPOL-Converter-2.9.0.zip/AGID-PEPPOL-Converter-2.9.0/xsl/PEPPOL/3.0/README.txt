qui ci va l'xsl risultato della compilazione degli schematron
serve perché lo prende in input il tool di conversione
grazie e arrivederci