https://github.com/ConnectingEurope/eInvoicing-EN16931

EN16931 Validation artefacts v.1.3.6