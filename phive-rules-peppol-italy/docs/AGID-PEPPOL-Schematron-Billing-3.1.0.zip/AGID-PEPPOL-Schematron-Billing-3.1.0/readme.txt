ISO Schematron business rules
