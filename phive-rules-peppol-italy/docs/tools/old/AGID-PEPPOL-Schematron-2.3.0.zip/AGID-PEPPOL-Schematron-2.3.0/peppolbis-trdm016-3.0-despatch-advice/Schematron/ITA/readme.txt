Documento di Trasporto

Peppol BIS 3.0.8

NOTA: Customizzazione del DDT con estensione di elementi.

Customization ID:
urn:fdc:peppol.eu:poacc:trns:despatch_advice:3:extended:urn:www.agid.gov.it:trns:ddt:3.1