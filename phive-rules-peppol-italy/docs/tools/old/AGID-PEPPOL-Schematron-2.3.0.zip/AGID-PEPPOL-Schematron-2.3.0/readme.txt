ISO Schematron business rules
