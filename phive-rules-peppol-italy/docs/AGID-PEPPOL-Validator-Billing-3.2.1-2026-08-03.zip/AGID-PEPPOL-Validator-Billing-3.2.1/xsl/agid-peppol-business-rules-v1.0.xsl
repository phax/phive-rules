<xsl:stylesheet version="1.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:xs="http://www.w3.org/2001/XMLSchema"
xmlns:sch="http://purl.oclc.org/dsdl/schematron"
exclude-result-prefixes="sch xs">
	<xsl:output method="html"
	doctype-system="about:legacy-compat"
	encoding="UTF-8"
	indent="yes" />
	<xs:import namespace="http://purl.oclc.org/dsdl/schematron" schemaLocation="../xsd/iso/schematron/iso-schematron.xsd"/>
	<xsl:variable name="transaction" select="/sch:schema/sch:title"/>
	
	<xsl:template match="/">
		<html data-transaction="{$transaction}">
			<head>
				<title><xsl:value-of select="$transaction"/></title>
				<meta charset="utf-8"/>
				<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
				<meta name="viewport" content="width=device-width, initial-scale=1"/>
				
				<link rel="stylesheet" href="../css/bootstrap.css"/>
				<link rel="stylesheet" href="../css/structure.css"/>
				<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous"/>
				<link rel="stylesheet" href="../css/agid-custom.css"/>
				
				<!--[if lt IE 9]>
					<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
					<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
				<![endif]-->
				<script src="../js/jquery.js"/>
				<script src="../js/bootstrap.js"/>
				<script type="text/javascript">
					//<![CDATA[
						debugger;//@ sourceURL=agid.js
						$(function () {
						var $html = $("html");
						var source = window.location.href.split('?')[0];
						var transaction = $html.data("transaction");
						
						$("#rule").hide();
						$("#rules").show();
						
						$("#path").on("click", "li.subcontext a", function(e) {
						e.preventDefault();
						var ctx = $("#" + $(this).attr("href"));
						changeContext(ctx);
						});
						
						$("#rules tr > td > a").click(function(e) {
						e.preventDefault();
						var ctx = $(this);
						changeContext(ctx);
						});
						
						function changeContext(ctx) {
						var branch = ctx.closest("tr"), activeContext = branch.find("> td > a").text();
						
						$("#path").html('<li><a href="'+source+'">'+transaction+'</a></li><li class="active">'+activeContext+'</li>');
						// <li><a href="../../../">Home</a></li>
						$("#context").text(activeContext);
						$("#rules").hide();
						$("#rule").find(".message").text(branch.find(".message").text()).end()
						.find(".context").text(branch.data("context")).end()
						.find(".test").text(branch.data("test")).end().show();
						}
						});
					//]]>
				</script>
			</head>
			<body>
				<div id="main" class="container">
					
					<ol id="path" class="breadcrumb">
						<!--li><a href="#">Home</a></li-->
						<li class="active"><xsl:value-of select="$transaction"/></li>
					</ol>
					
					<div class="page-header">
						<h1 id="context">
							<xsl:value-of select="$transaction"/>
						</h1>
					</div>
					
					<div id="rules" class="table-responsive">
						<table class="table table-striped">
							<thead>
								<tr>
									<th>Identifier/Error message</th>
									<th style="width: 5%">Flag</th>
								</tr>
							</thead>
							<tbody id="rules">
								<xsl:apply-templates select="//sch:rule[sch:assert]"/>
							</tbody>
						</table>
					</div>

					<dl id="rule" class="dl-horizontal">
						<dt>Message</dt>
						<dd><p class="message lead"></p></dd>
					
						<dt>Context</dt>
						<dd><code class="context"></code></dd>
					
						<dt>Test</dt>
						<dd><code class="test"></code></dd>
					</dl>
					
				</div>
			</body>
		</html>
	</xsl:template>
	
	<xsl:template match="sch:rule" priority="1">
		<xsl:variable name="ruleCtx" select="@context"/>
		<xsl:apply-templates select="sch:assert">
			<xsl:with-param name="ruleCtx" select="$ruleCtx"/>
		</xsl:apply-templates>
	</xsl:template>

	<xsl:template match="sch:assert" priority="1">
		<xsl:param name="ruleCtx"/>
		<xsl:variable name="ruleTest" select="@test"/>
		<xsl:variable name="ruleID" select="@id"/>
		<xsl:variable name="ruleFlag" select="@flag"/>
		<xsl:variable name="ruleText" select="text()"/>
		<tr id="{$ruleID}" data-context="{$ruleCtx}" data-test="{$ruleTest}">
			<td>
				<a href="#"><xsl:value-of select="$ruleID"/></a>
				<br/><span class="message"><xsl:value-of select="$ruleText"/></span>
			</td>
			<td style="width: 5%;">
				<xsl:value-of select="$ruleFlag"/>
			</td>
		</tr>
	</xsl:template>
	
</xsl:stylesheet>					