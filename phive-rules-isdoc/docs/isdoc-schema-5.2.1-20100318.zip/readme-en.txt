
=====================================================================
                 ISDOC XML schema for invoice exchange
=====================================================================

                       Version 5.2.1 from 2010-03-18
                       
                          (c) 2010 ICT UNIE o.s.
   Association for Information Technologies and Telecommunications
                             http://www.ictu.cz/
  (c) 2009 Association for Information Society, http://www.spis.cz/

=====================================================================

Invoice exchange format is formally defined in the attached
schema. Format was created and it is further maintained by Working
Group for Electronic Data Interchange Standards of Association for
Information Society (SPIS).

Content of distribution:
------------------------

xsd/*    - schemas in W3C XML Schema

           isdoc-invoice-5.2.1.xsd       - base schema

           isdoc-invoice-dsig-5.2.1.xsd  - schema validating also structure
	   			         of an embeded digital signature

           xmldsig-core-schema.xsd     - XML Signature schema

doc-cs/* - hypertext schema documentation with Czech comments

doc-en/* - hypertext schema documentation with English comments

Note:
-----

Use isdoc-invoice-5.2.1.xsd schema when validating invoice without
a digital signature. Use isdoc-invoice-dsig-5.2.1.xsd schema for
validation of invoice with a digital signature. This schema
automatically imports other two schemas necessary for validation.

Schema limitations:
-------------------

In its version 5.2.1 the schema does not define very strict constraints,
it merely defines basic structure and datatypes of invoice. It is
likely that in a future the schema will be augmented in order to
provide more precise data validation.

Changes since version 5.2 from 2009-10-25:
------------------------------------------

* schema can be used also for validation of documents using older versions
  of ISDOC because validation of version attribute was relaxed

Changes since version 5.2 from 2009-07-07:
------------------------------------------

* schema was not changed, only English comments were added

* hypertext schema documentation is now available in two version --
  with Czech or English comments

* schema diagrams in the hypertext documentation now use PNG format to
  decrease volume of documentation

Changes since previous version 5.1:
-----------------------------------

* UserID and CatalogFirmIdentification elements are now optional

* data type for ZIP code (PostalZoneType) was changed from xs:integer
  to xs:string

* more strict validation of UUID datatype (UUIDType). Now value must
  conform to the following pattern
  [0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}

* identification of issuing system can be stored inside newly added
  IssuingSystem element

* identifier of an invoice line (ID element inside InvoiceLine
  element) is now limited in its length to 36 characters

* ExternalOrderID element made optional inside OrderLineReference
  element


Contact: info@isdoc.cz, www.isdoc.cz
