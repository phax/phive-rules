﻿
=====================================================================
                  XML schéma pro výměnu faktur ISDOC
=====================================================================

                        Verze 5.3 z 14.2.2011

           (c) 2010, 2011 ICT UNIE o.s., http://www.ictu.cz/
       (c) 2009 Sdružení pro informační společnost, www.spis.cz

=====================================================================

Přiložená schémata formálně definují výměnný formát faktur definovaný 
Pracovní skupinou pro elektronické standardy výměny dat sdružení SPIS.

Obsah distribuce:
-----------------

xsd/*    - schémata v jazyce W3C XML Schema

           isdoc-invoice-5.3.xsd       - základní schéma

           isdoc-invoice-dsig-5.3.xsd  - schéma validující i strukturu 
                                         vloženého digitálního podpisu

           xmldsig-core-schema.xsd     - schéma XML Signature                                    

doc-cs/* - hypertextová dokumentace W3C XML Schematu s českými komentáři

doc-en/* - hypertextová dokumentace W3C XML Schematu s anglickými komentáři


Poznámka:
---------

Použijte schéma isdoc-invoice-5.3.xsd, pokud budete potřebovat validovat pouze 
samotnou fakturu bez elektronického podpisu. V případě validace vč. podpisu
použijte schéma isdoc-invoice-dsig-5.3.xsd, které pomocí příkazů import a 
redefine automaticky použije i obě další schémata.

Omezení schémat:
----------------

Ve verzi 5.3 nedefinuje schéma příliš striktní kontroly, popisuje
pouze základní strukturu faktury a datové typy. Je pravděpodobné, že
v budoucnu bude schéma vylepšeno tak, aby provádělo důslednější
kontroly dat.

 
Změny oproti verzi 5.2.3 z 14.2.2011:
-------------------------------------

* přidán nový druh dokumentů "zjednodušený daňový doklad"
  (DocumentType = 7)

  * elementy AccountingCustomerParty a Details jsou nepovinné pro
    zjednodušené daňové doklady

  * přidán nový element AnonymousCustomerParty, který je povinný pro
    zjednodušené daňové doklady

* přidán nový element Preformatted, který umožňuje reprezentovat
  identifikaci zápisu v rejstříku jako jeden řetězec v případech, kdy
  není možné rozlišit jednotlivé položky (RegisterKeptAt,
  RegisterFileRef, RegisterDate)

* přidán nový element OriginalDocumentReferences, který může obsahovat
  více odkazů na původní doklady (OriginalDocumentReference); pro
  zachování zpětné kompatibility je pořád možné uvádět odkaz na jeden
  dokument bez nutnosti jeho obalení elementem
  OriginalDocumentReferences

* u elementů OrderReference, DeliveryNoteReference,
  OriginalDocumentReference přidán nepovinný podelement UUID
  a podelement IssueDate změněn na nepovinný

* hodnoty typu UUIDType nyní mohou v souladu s RFC 4122 při vyjádření
  čísel v šestnáctkové soustavě používat i malá písmena 'a' až 'f'

* přidán nepovinný element VATApplicable pro indikaci toho, zda je
  dokument předmětem DPH (element je ve schématu kvůli zpětné
  kompatibilitě nepovinný, ale dokumenty od verze 5.3 výše jej musí
  obsahovat)

* přidán nepovinný řádkový element VATApplicable pro indikaci toho, 
  zda je řádka dokumentu předmětem DPH

* přidán nepovinný řádkový element VATNote pro citaci paragrafu zákona
  osvobozujícího položku od daně

* přidán nepovinný element VATApplicable pro indikaci toho, zda je
  řádka v daňové rekapitulaci předmětem DPH

* přidán nepovinný element ElectronicPossibilityAgreementReference pro
  zapsání odkazu na dokument, kterým se strany dohodly na elektronické
  fakturaci (element je ve schématu kvůli zpětné kompatibilitě
  nepovinný, ale dokumenty od verze 5.3 výše jej musí obsahovat)

* přidány nepovinné elementy LineExtensionAmountBeforeDiscount
  a LineExtensionAmountTaxInclusiveBeforeDiscount, aby bylo možné vyplnit 
  příjemci i ceny před slevami.

* element Item byl změněn na nepovinný


Změny oproti verzi 5.2.2 z 7.12.2010:
-------------------------------------
* přidán nový kód pro platbu dobírkou (element PaymentMeansCode)
  50 -  Platba dobírkou


Změny oproti verzi 5.2.1 z 18.3.2010:
-------------------------------------
* na konci dokumentu může být více elementů Signature


Změny oproti verzi 5.2 z 25.10.2009:
------------------------------------

* schéma lze použít i pro validaci dokumentů starších verzí ISDOC,
  protože není definována přesná verze formátu ISDOC v atributu version

Změny oproti verzi 5.2 z 7.7.2009:
----------------------------------

* ve schématu nebyly provedeny žádné obsahové změny, byly však
  doplněny komentáře v angličtině

* hypertextová dokumentace je nyní dostupná ve dvou verzích --
  s českými a anglickými komentáři

* diagramy v hypertextové dokumentaci používají formát PNG pro menší
  objem dat

Změny oproti předchozí verzi 5.1:
---------------------------------

* elementy UserID a CatalogFirmIdentification změněny na nepovinné

* datový typ pro PSČ (PostalZoneType) změněn z xs:integer na xs:string

* zpřísněna kontrola datového typu pro UUID (UUIDType). Nyní se
  kontroluje, zda má hodnota tvar
  [0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}

* přidán nepovinný element IssuingSystem, do kterého lze uložit
  identifikaci systému, který odesílá/generuje fakturu

* délka identifikátoru řádky faktury (element ID uvnitř elementu
  InvoiceLine) byla omezena na 36 znaků

* element ExternalOrderID je nyní uvnitř elementu OrderLineReference
  nepovinný



Kontakt: info@isdoc.cz, www.isdoc.cz
