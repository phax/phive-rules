# ISO 6523 ICD List

The content of this folder is a copy of
http://www.cyber-identity.com/download/ICD-list.pdf
to have a secured copy of the list of International Code Designators for ISO 6523.

Last update: **2018-05-16**
Last contained ICD value: **0189**

See https://en.wikipedia.org/wiki/ISO/IEC_6523 for a general description of ISO 6523. 
