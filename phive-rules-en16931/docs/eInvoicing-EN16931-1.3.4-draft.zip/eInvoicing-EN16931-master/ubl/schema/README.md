# UBL XML Schema

The XML Schema (XSD) of OASIS UBL 2.1 can be downloaded from OASIS.

The ZIP file is located at http://docs.oasis-open.org/ubl/os-UBL-2.1/UBL-2.1.zip
