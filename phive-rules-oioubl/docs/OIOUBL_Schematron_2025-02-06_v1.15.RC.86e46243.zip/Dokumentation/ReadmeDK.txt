ReadmeDK.txt
Revideret - 1.15.RC = (06.02.2025).


OIOUBL-2.1 schematron validerings-stylesheets
----------------------------------------------


1.0 Anvendelse
--------------
Anvendes til at validere om XML eksempelfil overholder reglerne i OIOUBL subset.
Følgende OIOUBL dokumenttyper kan valideres:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

Et dokument, f.eks. en faktura, kan valideres således:
msxsl.exe <XML dokument filnavn> OIOUBL_Invoice_Schematron.xsl -o resultat.xml

Hvis fakturaen validerer OK skrives alene en overskrift til resultat.xml, ellers listes alle fundne fejl.


2.0 Forudsætninger
------------------
Det forudsættes at eksempelfilen er valideret korrekt med det tilhørende UBL-2.1 XSD schema inden schematron stylesheetet anvendes.


3.0 Release Notes
-----------------
Schematron ændringer fra 1.14.2 til 1.15.RC
- UAN-3872: I UTS er der kun tilladt at benytte CustomizationID" = OIOUBL-2.1"
- UAN-2871: Opdatering af validering profile-id version i UTS
- UAN-5080: Opdatering af kodelister for landekoder og valutakoder. Nye værdier tilføjet.
- UAN-4610: Standardisering af OIOUBL 2.1 kodeliste schematron-filer
- UAN-5139: Opstramning af momsvalidering.
            F-LIB400: Validerer om TaxSubtotal/TaxAmount og moms procent på linjer = 0, når der er tale om ZeroRated
            F-LIB401: Validerer om TaxSubtotal/TaxAmount på linjer er korrekt beregnet for moms procent > 0 % og StandardRated (inkl. accepteret tolerance +/- 1.00)
            F-LIB402: Validerer om TaxableAmount på hoved niveau er lig med summen fra linjerne (inkl. accepteret tolerance +/- 1.00)


4.0 Revisionslog
----------------
2016.09.15  Version 1.8.0 frigivet.
2017.09.15  Version 1.9.0 frigivet.
2018.09.15  Version 1.10.0 frigivet.
2019.04.08  Version 1.11.1 frigivet.
2022.01.15  Version 1.12.DEV betaversion
2022.03.10  Version 1.12.RC1 ReleaseCandidate
2022.04.06  Version 1.12 frigivet
2022.05.11  Version 1.12.2 frigivet
2022.05.19  Version 1.12.3 frigivet
2022.09.30  Version 1.13.0.RC1 Release Candidate
2022.10.28  Version 1.13.0 frigivet.
2023.01.06  Version 1.13.1 frigivet.
2023.01.18  Version 1.13.2 frigivet.
2024.06.14  Version 1.14.0 frigivet.
2024.06.20  Version 1.14.1 frigivet.
2024.06.21  Version 1.14.2 frigivet.
2025.02.06  Version 1.15.RC Release Candidate.

5.0 Rapportering af fejl og mangler etc.
----------------------------------------
Information om fejl, mangler, og andet relevant, sendes til:
    support@nemhandel.dk

På forhånd tak!
