﻿ReadmeUK.txt
Revision: 2012.06.15 by Ivan Willer, mySupply ApS.


OIOUBL-2.02 schematron stylesheets
----------------------------------


1.0 Purpose and usage
---------------------
Validation of OIOUBL instances.
The following OIOUBL document types are currently supported:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml

To validate, execute the following command (shown for Invoice):
msxsl.exe <instancefilename> OIOUBL_Invoice_Schematron.xsl -o result.xml

If the validation is successful, only the title is written to result.xml; otherwise the errors are listed.


2.0 Prerequisites
-----------------
The instance file must validate OK with the UBL-2.0 XSD schema.


3.0 Release Notes
-----------------
723: Number of allowed decimals on Quantity is changed to 6.
730: It's now possible to have Delivery address on header and delivery dates on line.
    - ActualDeliveryDate, RequestedDeliveryPeriod, Delivery Location and Delivery Party may be declared at header or
      line independent of whether the other three classes are shown in the header or line level.
823: Validation result for LineExtensionAmount depends on .NET or JAVA interpreter.
    - Implementation of sum/comparison is updated, to compensated for Javas calculations.
828: No validation if TaxTotal elements have same TaxScheme code.
    - The same TaxScheme.ID can be listed several times in the same TaxTotal class. The same calculation formula
      must not appear more than once in a TaxTotal class.
829: No validation for empty ID under FinancialInstitutionBranch for BetalingsMådeKode "42" and KontoType "DK:BANK"
    - Check added
841: SchemeID must be updated to version 1.2
    - SchemeID updated to version 1.2 according to new Tax Category ID code list.
848: No validation for InstructionID in PaymentMeans is numeric
    - Check added for PaymentMeansCode 93, PaymentID 71 and 75, and for PaymentMeansCode 50, PaymentID 04 and 15.
927: Negative AllowanceCharge on line
    - If InvoicedQuantity or Price.PriceAmount are negative, the AllowanceCharge.Amount can be negative.
934: <ext:UBLExtension> validation
    - It's now validated, that ID is in approved interval if ExtensionAgencyID="Digitaliseringsstyrelsen"
957: New code lists based on PEPPOL
    - PEPPOL elements added for lists EndpointID and PartyID.

Changes to 1.4.2
823: Changed tolerance to +/- 0,005 in calculation of LineExtensionAmount
957: Added space in "ISO 6523" -> it was removed in earlier release
828: Added documentation to Excelsheet for the correction.


4.0 Revision log
----------------
2010.09.15  Version 1.2 released.
2011.12.01  Version 1.3 released.
2012.06.15  Version 1.4.1 released.
2012.06.15  Version 1.4.2 released.


5.0 Your feedback
-----------------
Please post your comments and feedback to the following email address:
    support@nemhandel.dk

Thanks!
