﻿ReadmeDK.txt
Revideret: 15.06.2012 af Ivan Willer, mySupply ApS.


OIOUBL-2.02 schematron validerings-stylesheets
----------------------------------------------


1.0 Anvendelse
--------------
Anvendes til at validere om XML eksempelfil overholder reglerne i OIOUBL subset.
Følgende OIOUBL dokumenttyper kan valideres:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml

Du validerer, f.eks. en faktura, således:
msxsl.exe <filnavn for fakturafilen> OIOUBL_Invoice_Schematron.xsl -o resultat.xml

Hvis fakturaen validerer OK skrives alene en overskrift til resultat.xml, ellers listes alle fundne fejl.


2.0 Forudsætninger
------------------
Det forudsættes at eksempelfilen er valideret korrekt med det tilhørende UBL-2.0 XSD schema
inden schematron stylesheetet anvendes.


3.0 Release Notes
-----------------
723: Antal tilladte decimaler på Quantity ændres til 6.
730: Det er nu muligt at angive Delivery adresse på header og leveringsdatoer på linjen
    - ActualDeliveryDate, RequestedDeliveryPeriod, DeliveryLocation og DeliveryParty, kan angives på header eller linjen
      uafhængig af, om de øvrige tre klasser er angivet på header- eller linjeniveau.
823: Valideringsresultat for LineExtensionAmount afhænger af .NET eller JAVA fortolker
    - Implementationen af summering/sammenligning er opdateret, således at der tages hensyn til Javas udregninger.
828: Der valideres ikke om TaxTotal elementerne har samme pligtkode.
    - Samme pligtkode må kun forefindes flere gange i en TaxTotal klasse. Samme beregningsformel må ikke forefindes mere
      end en gang i en TaxTotal klasse.
829: Der valideres ikke for tomt ID under FinancialInstitutionBranch for BetalingsMådeKode "42" og KontoType "DK:BANK"
    - Check tilføjet
841: SchemeID skal opdateres til version 1.2
    - SchemeID opdateret til version 1.2 jf. ny Tax Category ID kodeliste også med nye fedtafgifter og naturgasafgifter.
848: Der valideres ikke for om InstructionID i PaymentMeans er en numerisk værdi
    - Check tilføjet for PaymentMeansCode 93, PaymentID 71 og 75, samt PaymentMeansCode 50, PaymentID 04 og 15.
927: Negativ AllowanceCharge på linjen
    - Hvis InvoicedQuantity eller Price.PriceAmount er negativ, må AllowanceCharge.Amount godt være negativ.
934: <ext:UBLExtension> validering
    - Det valideres nu, om ID ligger i godkendt interval hvis ExtensionAgencyID="Digitaliseringsstyrelsen"
957: Nye kodelister på grund af PEPPOL
    - PEPPOL elementer tilføjet i listerne EndpointID og PartyID.

Rettelser til 1.4.2
823: Ændret tolerance til +/- 0,005 i beregning af LineExtensionAmount
957: Indsat mellemrum i "ISO 6523" -> i tidligere rettelse var det fjernet.
828: Tilføjet rettelser til dokumentation Excelark for rettelsen.


4.0 Revisionslog
----------------
2010.09.15  Version 1.2 frigivet.
2011.12.01  Version 1.3 frigivet.
2012.06.15  Version 1.4.1 frigivet.
2012.06.15  Version 1.4.2 frigivet.


5.0 Rapportering af fejl og mangler etc.
----------------------------------------
Information om fejl, mangler, og andet relevant, modtages meget gerne på følgende mailadresse:
    support@nemhandel.dk

På forhånd tak!
