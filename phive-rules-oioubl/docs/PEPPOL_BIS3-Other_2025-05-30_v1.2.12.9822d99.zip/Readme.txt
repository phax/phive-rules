Peppol BIS3.0 "Other" XSLT Schematron
-------------------------------------

1.0 Purpose
-----------
The package contains the XSLT versions of the schematron files for the Peppol BIS3 documents other than the Peppol BIS 3.0 Billing documents
(Invoice and Credit note)


2.0 Content
-----------
The Schematron folder contains:
- PEPPOLBIS-T01.xslt (Order)
- PEPPOLBIS-T16.xslt (Despatch Advice)
- PEPPOLBIS-T19.xslt (Catalogue)
- PEPPOLBIS-T58.xslt (Catalogue Response)
- PEPPOLBIS-T71.xslt (Message Level Response)
- PEPPOLBIS-T76.xslt (Order Response)
- PEPPOLBIS-T77.xslt (Punch Out)
- PEPPOLBIS-T110.xslt (Order Agreement)
- PEPPOLBIS-T111.xslt (Invoice Response)
- PEPPOLBIS-T114.xslt (Order Change)
- PEPPOLBIS-T115.xslt (Order Cancellation)
- PEPPOLBIS-T116.xslt (Order Response Advanced)


This package also contains the Peppol SCH validation files and Example-files, published at https://docs.peppol.eu/poacc/upgrade-3/2025-Q2/

Current files are based on version 3.0.15: https://docs.peppol.eu/poacc/upgrade-3/2025-Q2/release-notes/

Should there be any doubt about the XSLT files, the *.sch files are the common reference.


3.0 Release Notes
-----------------
- Release of the Danish XSLT version of the Peppol SCH files (May release 2025 - version 3.0.15).
- Conversion MLR_2_OIOUBL_AppRes is removed from this package.
  - All OIOUBL conversions will be releases separately as a part of the OIOUBL 3 major release package on https://oioubl-demo.nemhandel.dk/oioubl/Overblik.html


PLEASE NOTE:
- Saxon-HE version 10.3 is used as XSLT engine for test of schematrons.


4.0 Revision log
----------------
- 2019.12.04  Version 1.0.0 mandatory (based on OpenPeppol version 3.0.3)
- 2020.05.15  Version 1.1.0 mandatory (based on OpenPeppol version 3.0.4)
- 2020.11.16  Version 1.2.0 mandatory (based on OpenPeppol version 3.0.5)
- 2020.11.16  Version 1.2.1 mandatory (based on OpenPeppol version 3.0.6)
- 2021.05.07  Version 1.2.2 mandatory (based on OpenPeppol version 3.0.7)
- 2021.11.15  Version 1.2.3 mandatory (based on OpenPeppol version 3.0.8)
- 2022.05.12  Version 1.2.4 mandatory (based on OpenPeppol version 3.0.9)
- 2022.06.22  Version 1.2.5 mandatory (update of OpenPeppol version 3.0.9)
- 2022.11.18  Version 1.2.6 mandatory (based on OpenPeppol version 3.0.10)
- 2023.05.23  Version 1.2.7 mandatory (based on OpenPeppol version 3.0.11)
- 2023.12.22  Version 1.2.8 mandatory (based on OpenPeppol version 3.0.12)
- 2024.06.12  Version 1.2.9 mandatory (based on OpenPeppol version 3.0.13)
- 2025.01.23  Version 1.2.10 mandatory (based on OpenPeppol version 3.0.14)
- 2025.02.12  Version 1.2.11 mandatory (based on OpenPeppol version 3.0.14 Hotfix)
- 2025.05.30  Version 1.2.12 mandatory (based on OpenPeppol version 3.0.15)

5.0 Your feedback
-----------------
Please post your comments and feedback to the following address:

https://nemhandel.dk/nemhandel-support-og-hjaelp

Thanks!
