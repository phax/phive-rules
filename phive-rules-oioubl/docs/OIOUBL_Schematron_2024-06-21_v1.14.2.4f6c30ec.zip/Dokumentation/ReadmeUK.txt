ReadmeUK.txt
Revision - 1.14.2 (21.06.2024).



OIOUBL-2.1 schematron stylesheet
----------------------------------


1.0 Purpose and usage
---------------------
Validation of OIOUBL instances.
The following OIOUBL document types are currently supported:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml


To validate, execute the following command (shown for Invoice):
msxsl.exe <XML document filename> OIOUBL_Invoice_Schematron.xsl -o result.xml

If the validation is successful, only the title is written to result.xml; otherwise the errors are listed.



2.0 Prerequisites
-----------------
The instance file must validate OK with the UBL-2.1 XSD schema.


3.0 Release Notes
---------------------
Changes from version  1.14.1 til 1.14.2
- UAN-3915: The use of DK:CPR as schemaID is allowed on EndpointID

Changes from version 1.14.0 til 1.14.1
- UAN-3894: The use of DK:CPR as schemaID is allowed on PartyIdentification\ID and PartyLegalEntity\CompanyID

Changes from version 1.13.2 to 1.14
- NH-2571: It's not longer posible to use DK:CPR as SchemaID for EndpointID, PartyIdentification\ID, samt PartyLegalEntity\CompanyID
- NH-1480: Codelists are now imported during the build process as individual codelist files
- UAN-3636: Added validation for TaxTotal on line level, the ensure the TaxAmount equals the sum of TaxAmount in TaxSubtotal


4.0 Revision log
----------------
2016.09.15  Version 1.8.0 released.
2017.09.15  Version 1.9.0 released.
2018.09.15  Version 1.10.0 released.
2019.04.08  Version 1.11.1 released.
2022.01.15  Version 1.12.DEV betaversion
2022.03.10  Version 1.12.RC1 ReleaseCandidate
2022.04.06  Version 1.12 released
2022.05.11  Version 1.12.2 released
2022.05.19  Version 1.12.3 released
2022.09.30  Version 1.13.0 ReleaseCandidate
2022.10.28  Version 1.13.0 Released
2023.01.06  Version 1.13.1 Released
2024.06.14  Version 1.14.0 Released
2024.06.20  Version 1.14.1 Released
2024.06.21  Version 1.14.2 Released


5.0 Your feedback
-----------------
Please post your comments and feedback to:
    support@nemhandel.dk

Thanks!
