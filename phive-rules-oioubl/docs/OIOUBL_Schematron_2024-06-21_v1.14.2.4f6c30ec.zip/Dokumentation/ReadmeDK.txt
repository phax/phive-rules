ReadmeDK.txt
Revideret - 1.14.2 (21.06.2024).


OIOUBL-2.1 schematron validerings-stylesheets
----------------------------------------------


1.0 Anvendelse
--------------
Anvendes til at validere om XML eksempelfil overholder reglerne i OIOUBL subset.
Følgende OIOUBL dokumenttyper kan valideres:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

Et dokument, f.eks. en faktura, kan valideres således:
msxsl.exe <XML dokument filnavn> OIOUBL_Invoice_Schematron.xsl -o resultat.xml

Hvis fakturaen validerer OK skrives alene en overskrift til resultat.xml, ellers listes alle fundne fejl.


2.0 Forudsætninger
------------------
Det forudsættes at eksempelfilen er valideret korrekt med det tilhørende UBL-2.1 XSD schema inden schematron stylesheetet anvendes.


3.0 Release Notes
-----------------
Schematron ændringer fra 1.14.1 til 1.14.2
- UAN-3915: Det tillades af benytte DK:CPR på EndpointID

Schematron ændringer fra 1.14.0 til 1.14.1
- UAN-3894: Det tillades af benytte DK:CPR på PartyIdentification\ID, samt PartyLegalEntity\CompanyID

Schematron ændringer fra 1.13.2 til 1.14
- NH-2571:Der er ikke længere muligt, at benytte DK:CPR som SchemaID for EndpointID, PartyIdentification\ID, samt PartyLegalEntity\CompanyID
- NH-1480: Kodeliste importeringen er omlagt fra en include-fil til selvstændige kodelistefiler som inporteres under byggeprocessen
- UAN-3636: Der er indført validering af TaxTotal på linjeniveau, således at TaxAmount skal være = summen af TaxAmount i TaxSubtotal

4.0 Revisionslog
----------------
2016.09.15  Version 1.8.0 frigivet.
2017.09.15  Version 1.9.0 frigivet.
2018.09.15  Version 1.10.0 frigivet.
2019.04.08  Version 1.11.1 frigivet.
2022.01.15  Version 1.12.DEV betaversion
2022.03.10  Version 1.12.RC1 ReleaseCandidate
2022.04.06  Version 1.12 frigivet
2022.05.11  Version 1.12.2 frigivet
2022.05.19  Version 1.12.3 frigivet
2022.09.30  Version 1.13.0.RC1 Release Candidate
2022.10.28  Version 1.13.0 frigivet.
2023.01.06  Version 1.13.1 frigivet.
2023.01.18  Version 1.13.2 frigivet.
2024.06.14  Version 1.14.0 frigivet.
2024.06.20  Version 1.14.1 frigivet.
2024.06.21  Version 1.14.2 frigivet.

5.0 Rapportering af fejl og mangler etc.
----------------------------------------
Information om fejl, mangler, og andet relevant, sendes til:
    support@nemhandel.dk

På forhånd tak!
