ReadmeUK.txt
Revision - 1.12.3 (Released 19.05.2022).



OIOUBL-2.1 schematron stylesheets
----------------------------------


1.0 Purpose and usage
---------------------
Validation of OIOUBL instances.
The following OIOUBL document types are currently supported:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

To validate, execute the following command (shown for Invoice):
msxsl.exe <XML document filename> OIOUBL_Invoice_Schematron.xsl -o result.xml

If the validation is successful, only the title is written to result.xml; otherwise the errors are listed.

To validate Peppol documents, a XSLT2 tool must be used, using the Peppol validation artifacts (https://docs.peppol.eu/poacc/billing/3.0/ og https://docs.peppol.eu/poacc/upgrade-3/).


2.0 Prerequisites
-----------------
The instance file must validate OK with the UBL-2.1 XSD schema.


3.0 Release Notes
-----------------
Changes from version 1.12.2 to 1.12.3:

Functional / technical changes:
- NH-2008: Update of validation of CustomizationID to ensure that 'OIOUBL-2.00' are not allowed


Changes from version 1.11.1 to 1.12.2:

Functional / technical changes:
- NH-1022: Support for use of environmental codes and other product certificates in invoices and credit notes and other OIOUBL documents. The item.certifcate element is used for that purpose.
- NH-1031: Technical support for UBL-2.1 XSD schemas in OIOUBL schematrons.
- NH-1207: Update of all examples files with use of UBL-2.1 XSD schemas.
- NH-1464: Cleanup old XSD's in release zip-file. Only sub-folder UBL_v2.1 remains, and other subfolders are removed.


Corrections:
- NH-130: Improved error messages regarding LineExtensionAmount.
- NH-196: Improved error messages.
- NH-50: Alignment of price calculations and use of OrderableUnitFactorRate in the OIOUBL Order and Credit Note. The price calculation for the OIOUBL Invoice was update in schematron version 1.11 from 2019, due to align with Peppol BIS Billing. Similar updates are now implemented in the OIOUBL Order and Credit Note.
- NH-501: Removal of validation on OrderableUnitFactorRate in the OIOUBL Credit Note. The invoice and the credit note are now validated using the same method.
- NH-836: Addition of missing mimecodes (xslx and ods) related to use of DocumentReferences.
- NH-457: New values added to OIOUBL code list for EndpointID.
- NH-47: Correction regarding valiation of Payable Amount (reason for correction: the Order and the Credite Note. Validation in Java schematron generated an error were -0.00 was not equal to 0.00)
- NH-51: Removal of decimal limitation on "line quantity" in all relevant OIOUBL documents (Invoice, Credit Note, Order, Order Response and Order Change)
- NH-1199: Update of TaxTotal validation for StandardRated VAT, where 0% is used.
- NH-1461: Update of example files - related to certificate examples.
- NH-1481: OIOUBL FAQ 75 information regarding personal secure information.
- NH-1705: Correction after RC1: Update of validation of customazation id to ensure that both 'OIOUBL-2.0, 'OIOUBL-2.01', 'OIOUBL-2.02' and 'OIOUBL-2.1' are allowed
- NH-1998: Correction  F-LIB381 schematron rule regarding VAT

4.0 Revision log
----------------
2016.09.15  Version 1.8.0 released.
2017.09.15  Version 1.9.0 released.
2018.09.15  Version 1.10.0 released.
2019.04.08  Version 1.11.1 released.
2022.01.15  Version 1.12.DEV betaversion
2022.03.10  Version 1.12.RC1 ReleaseCandidate
2022.04.06  Version 1.12 released
2022.05.11  Version 1.12.2 released
2022.05.19  Version 1.12.3 released

5.0 Your feedback
-----------------
Please post your comments and feedback to:
    support@nemhandel.dk

Thanks!
