ReadmeDK.txt
Revideret - 1.12.3 (Releases 19.05.2022).


OIOUBL-2.1 schematron validerings-stylesheets
----------------------------------------------


1.0 Anvendelse
--------------
Anvendes til at validere om XML eksempelfil overholder reglerne i OIOUBL subset.
Følgende OIOUBL dokumenttyper kan valideres:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

Et dokument, f.eks. en faktura, kan valideres således:
msxsl.exe <XML dokument filnavn> OIOUBL_Invoice_Schematron.xsl -o resultat.xml

Hvis fakturaen validerer OK skrives alene en overskrift til resultat.xml, ellers listes alle fundne fejl.

For at kunne validere Peppol dokumenter, skal et XSLT2 værktøj benyttes sammen med Peppol validation artifacts (https://docs.peppol.eu/poacc/billing/3.0/ og https://docs.peppol.eu/poacc/upgrade-3/)


2.0 Forudsætninger
------------------
Det forudsættes at eksempelfilen er valideret korrekt med det tilhørende UBL-2.1 XSD schema inden schematron stylesheetet anvendes.


3.0 Release Notes
-----------------
Schematron ændringer fra 1.12.2 til 1.12.3:

Funktionelle / tekniske ændringer:
- NH-2008: Opdatering af validering af CustomizationID således at 'OIOUBL-2.00' ikke er tilladt


Schematron ændringer fra 1.11.1 til 1.12.2:

Funktionelle / tekniske ændringer:
- NH-1022: Understøttelse af miljømærker af fakturaer og kreditnota samt øvrige OIOUBL dokumenter. Teknisk anvendes item.certifcate elementet til dette formål. Yderligere dokumentation findes OIOUBL Miljømærker og andre produktcertifikater (G41) og OIOUBL EnvironmentalCode (K32).
- NH-1031: Teknisk understøttelse af UBL-2.1 XSD schemaer i OIOUBL schematroner.
- NH-1207: Opdatering af alle eksempelfiler med anvendelse af UBL-2.1 XSD schemaer.
- NH-1464: Oprydning gamle/udgåede XSD'er i release pakke | I den zip-filen som indeholder den nye version, findes der ikke folder schemas nu kun en sub-folder UBL_v2.1. Øvrige sub-foldere er fjernet.


Fejlrettelse:
- NH-130: Forbedring af fejltekster vedr. LineExtensionAmount, hvor beløbet nu indgår i fejlteksten.
- NH-196: Forbedring af fejltekster.
- NH-501: Fjernelse af validering af OrderableUnitFactorRate i kreditnota, således af faktura og kreditnota validering på samme måde.
- NH-50: Align Prisberegning og brugen af OrderableUnitFactorRate i Ordre og Kreditnota | I forbindelse med seneste OIOUBL schematron (version 1.11 fra 2019) blev prisberegningen og brugen af OrderableUnitFactorRate i fakturaen opdateret, så logikken var mere i overensstemmelse med logikken i Peppol BIS Billing. Tilsvarende opdateringer bliver nu implementeret for Ordre og Kreditnota.
- NH-836: Tilføjelse af mangelende mimecodes (xslx og ods) vedr. DokumentReferencer.
- NH-457: OIOUBL udvidelse af kodelisten for EndpointID
- NH-47: Fejlrettelse af schematronvalidering for Payable Amount (årsagen fejlvalidering opstod tidligere kun ved anvendelse af schematron i Java, hvor den fejlen var relateret til, at -0.00 var forskellige fra 0.00)
- NH-51: Fjernelse af decimal begrænsning på "line quantity" på alle relevante OIOUBL dokumenter (Faktura, Kreditnota, Ordre, Ordrebekræftelse og Ordreændring)
- NH-1199: Opdatering af TaxTotal validering for StandardRated med 0% moms
- NH-1461: Opdatering af eksempelfiler med certifikater | Eksempelfiler er opdateret og indgår nu også den zip-fil, der indeholder den nye version.
- NH-1481: OIOUBL FAQ 75 personfølsomme oplysninger
- NH-1705: Fejlrettelse efter RC1: Opdatering af validering af customazation id således, at både 'OIOUBL-2.0, 'OIOUBL-2.01', 'OIOUBL-2.02' og 'OIOUBL-2.1' er tilladt
- NH-1998: Fejrettelse efter Release: F-LIB381 schematron regel på moms.


4.0 Revisionslog
----------------
2016.09.15  Version 1.8.0 frigivet.
2017.09.15  Version 1.9.0 frigivet.
2018.09.15  Version 1.10.0 frigivet.
2019.04.08  Version 1.11.1 frigivet.
2022.01.15  Version 1.12.DEV betaversion
2022.03.10  Version 1.12.RC1 ReleaseCandidate
2022.04.06  Version 1.12 frigivet
2022.05.11  Version 1.12.2 frigivet
2022.05.19  Version 1.12.3 frigivet

5.0 Rapportering af fejl og mangler etc.
----------------------------------------
Information om fejl, mangler, og andet relevant, sendes til:
    support@nemhandel.dk

På forhånd tak!
