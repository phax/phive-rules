# Schematron files

This folder contains the Schematron files for PEPPOL BIS Billing 3.0.
Those prefixed with "PEPPOL" contains rules defined by OpenPEPPOL.
Those prefixed with "CEN" is provided by CEN TC434.

Rules provided by CEN TC434 in this folder is provided by version 1.3.14.1 of the TC434 validation artefacts, as [released here.](https://github.com/ConnectingEurope/eInvoicing-EN16931/releases)
