#!/bin/sh

mv /target/guide/* /target/site
rm -r /target/guide
